//
//  loginViewController.h
//  sql
//
//  Created by adithya on 7/6/18.
//  Copyright © 2018 adithya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>

@interface loginViewController : UIViewController{
sqlite3 *logindb;

NSString *databasePath;
}
@property (strong, nonatomic) IBOutlet UITextField *username;
@property (strong, nonatomic) IBOutlet UITextField *password;
@property (strong, nonatomic) IBOutlet UILabel *status;
- (IBAction)submit:(id)sender;


@end
