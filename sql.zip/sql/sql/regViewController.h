//
//  regViewController.h
//  sql
//
//  Created by adithya on 7/6/18.
//  Copyright © 2018 adithya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface regViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *user;
@property (strong, nonatomic) IBOutlet UITextField *passw;
- (IBAction)sub:(id)sender;

@end
