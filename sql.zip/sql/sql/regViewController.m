//
//  regViewController.m
//  sql
//
//  Created by adithya on 7/6/18.
//  Copyright © 2018 adithya. All rights reserved.
//

#import "regViewController.h"

@interface regViewController ()

@end

@implementation regViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)sub:(id)sender {
    if([self.user.text isEqualToString:@""] || [self.passw.text isEqualToString:@""]) {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Here comes a block." message:@"You missed something, please check your details and try again." delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
    }
    else{
        NSString *query=[NSString stringWithFormat:@"select * from login where username=\"%@\" and password=\"%@\"",self.user.text,self.passw.text];
        NSLog(@"%@",query);
    }
}
@end
