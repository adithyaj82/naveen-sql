//
//  main.m
//  NaveenTaskForCreativeSolutions
//
//  Created by brn.developers on 2/17/18.
//  Copyright © 2018 brn.developers. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
