//
//  AppDelegate.h
//  NaveenTaskForCreativeSolutions
//
//  Created by brn.developers on 2/17/18.
//  Copyright © 2018 brn.developers. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

