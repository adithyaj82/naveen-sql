//
//  SignInVC.swift
//  NaveenTaskForCreativeSolutions
//
//  Created by brn.developers on 2/17/18.
//  Copyright © 2018 brn.developers. All rights reserved.
//

import UIKit
import SQLite3
class SignInVC: UIViewController,UITextFieldDelegate {

    @IBOutlet var passwordTF: UITextField!
    @IBOutlet var phoneTF: UITextField!
    var storeUserPhoneNumber = NSMutableArray()
    var storeUserPassword = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Sign In here"
        
        passwordTF.delegate = self
        phoneTF.delegate = self
        print(storeUserPhoneNumber)
        print(storeUserPassword)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func signInButtonTap(_ sender: UIButton) {
        let stringToSearchPhoneNumber = phoneTF.text!
        let stringToSearchPassword = passwordTF.text!
        print(storeUserPassword)
        if (storeUserPhoneNumber.contains(stringToSearchPhoneNumber) && storeUserPassword.contains(stringToSearchPassword))  {
            NSLog("Term Exists")
        
        
            let successAlert = UIAlertController(title: "Success", message: "You have logged!", preferredStyle: .alert)
            
            let action = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
            successAlert.addAction(action)
            self.present(successAlert, animated: true, completion: nil)
            
            self.phoneTF.text = ""
            self.passwordTF.text = ""
            self.passwordTF.resignFirstResponder()
            
        }
        else{
            
            alertMessage(title: "error", message: "You have entred details are wrong")
            
        }
    }
    
    func alertMessage(title:String,message:String){
        
        let successAlert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let action = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
        successAlert.addAction(action)
        self.present(successAlert, animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
        
    }
    
}
