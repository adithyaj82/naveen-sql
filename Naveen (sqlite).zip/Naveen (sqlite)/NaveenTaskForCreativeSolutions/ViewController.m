//
//  ViewController.m
//  NaveenTaskForCreativeSolutions
//
//  Created by brn.developers on 2/17/18.
//  Copyright © 2018 brn.developers. All rights reserved.
//

#import "ViewController.h"
#import "NaveenTaskForCreativeSolutions-Swift.h"
#import <sqlite3.h>

@interface ViewController ()
@property NSMutableArray * phoneNumber;
@property NSMutableArray * password;
@property NSString * dataBasePath;
@property sqlite3 *DB;

@property (strong, nonatomic) IBOutlet UIScrollView *subView;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.phoneNumber = [[NSMutableArray alloc]init];
    self.password = [[NSMutableArray alloc]init];
    [self confirmingDelegaesToTextFields];
    NSString *docsDir;
    NSArray *dirPaths;
    
    dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    docsDir = dirPaths[0];
    
    self.dataBasePath = [[NSString alloc]initWithString:[docsDir stringByAppendingPathComponent:@"user.db"]];
    
    NSFileManager * fileManager = [NSFileManager defaultManager];
    
    if([fileManager fileExistsAtPath:self.dataBasePath] == NO){
        
        const char *dbPath = [self.dataBasePath UTF8String];
        
        if(sqlite3_open(dbPath, &_DB) == SQLITE_OK){
            
            char *errorMessage;
            const char *sqlStatement = "CREATE TABLE IF NOT EXISTS users(ID INTEGER PRIMARY KEY AUTOINCREMENT, FIRSTNAME TEXT, MIDDLENAME TEXT, LASTNAME TEXT, EMAILADD TEXT, PHONE TEXT, PASSWORD TEXT)";
            if(sqlite3_exec(self.DB, sqlStatement, NULL, NULL, &errorMessage) != SQLITE_OK ){
                
                NSLog(@"Failed To create/Connect");
                
            }
            sqlite3_close(self.DB);
        }
        else{
            
            NSLog(@"Failed To create/Connect");
        }
    
        
    }
   [self fetchData];
    
}
- (IBAction)onSubmitButtonTap:(id)sender {
    NSLog(@"%@",self.dataBasePath);
    if(self.firstNameTF.text.length == 0 || self.lastName.text.length == 0 ||
       self.middleNameTF.text.length == 0 ||
       self.emailTF.text.length == 0 ||
       self.passwordTF.text.length == 0 ||self.confirmPassword.text.length == 0)
    {
        
        [self alertMessageForTitile:@"Required" forMessage:@"Please Fill all Fields"];
        
    }
    else if (self.passwordTF.text != self.confirmPassword.text)
    {
        [self alertMessageForTitile:@"Error" forMessage:@"PassWord Does not Match"];
    }
    else{
    sqlite3_stmt * statement;
    const char *dbPath = [self.dataBasePath UTF8String];
    
    if(sqlite3_open(dbPath, &_DB) == SQLITE_OK){
        
        NSString * insertSql = [NSString stringWithFormat:@"INSERT INTO users (FIRSTNAME, MIDDLENAME, LASTNAME, EMAILADD, PHONE, PASSWORD) VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",self.firstNameTF.text,self.middleNameTF.text,self.lastName.text,self.emailTF.text,self.phoneNumberTF.text,self.passwordTF.text];
        
        const char * insertStatement = [insertSql UTF8String];
        sqlite3_prepare_v2(self.DB, insertStatement, -1, &statement, NULL);
        if(sqlite3_step(statement) == SQLITE_DONE){
            
            NSLog(@"data stored");
        }else{
            NSLog(@"data failed to store");
        }
        sqlite3_finalize(statement);
        sqlite3_close(self.DB);
    }
    [self fetchData];
    [self performSegueWithIdentifier:@"signInSegue" sender:sender];
    
    }
    
}
-(void)fetchData{
    NSLog(@"%@",self.dataBasePath);
    sqlite3_stmt * statement;
    const char *dbPath = [self.dataBasePath UTF8String];
    
    if(sqlite3_open(dbPath, &_DB) == SQLITE_OK){
        
        NSString * retrive = [NSString stringWithFormat:@"SELECT * from users"];
        const char *query = [retrive UTF8String];
        if(sqlite3_prepare_v2(self.DB, query, -1, &statement, NULL) == SQLITE_OK){
            
            while(sqlite3_step(statement) == SQLITE_ROW){
                
                //NSMutableArray *store
                NSString *storePhone = [NSString stringWithFormat:@"%s",sqlite3_column_text(statement, 5)];
                NSString *storePassword = [NSString stringWithFormat:@"%s",sqlite3_column_text(statement, 6)];
                NSLog(@"phoneNumber :%@",storePhone);
                NSLog(@"password :%@",storePassword);
                NSLog(@"%s",sqlite3_column_text(statement, 0));
                NSLog(@"%s",sqlite3_column_text(statement, 1));
                NSLog(@"%s",sqlite3_column_text(statement, 2));
                NSLog(@"%s",sqlite3_column_text(statement, 3));
                NSLog(@"%s",sqlite3_column_text(statement, 4));
                NSLog(@"%s",sqlite3_column_text(statement, 5));
                //NSLog(@"%s",sqlite3_column_text(statement, 6));
                [self.phoneNumber addObject:storePhone];
                [self.password addObject:storePassword];
            }
            
        }
        
        
    }
    
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    SignInVC * signInObj = segue.destinationViewController;
    
    signInObj.storeUserPhoneNumber = self.phoneNumber;
    signInObj.storeUserPassword = self.password;
    //signInObj.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)alertMessageForTitile:(NSString*)title
                  forMessage:(NSString*)message{
    
    UIAlertController *alertMessage = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleCancel handler:nil];
    [alertMessage addAction:action];
    [self presentViewController:alertMessage animated:YES completion:nil];
    
    
}
-(void)deleteDB{
    
    
}
-(void)update{
    
    
    
}
- (BOOL) validateEmail: (NSString *) candidate {
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[gmailyahoomail]+\\.[A-Za-z]{2,5}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    
    return [emailTest evaluateWithObject:candidate];
}
-(BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    
    if(textField == self.emailTF){
        if([self validateEmail:[self.emailTF text]]==1)
        {
            return YES;
        }else
        {
            [self alertMessageForTitile:@"Required" forMessage:@"Enter Proper Email Address"];
            return NO;
        }
        
    }
    return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
    {
    
     if(textField == self.middleNameTF)
    {
        return YES;
    }else if(textField == self.lastName)
    {
        return YES;
    }else if(textField == self.emailTF)
    {
        
    }else if(textField == self.phoneNumberTF)
    {
        self.subView.contentOffset = CGPointMake(0, self.phoneNumberTF.center.y-230);
        return YES;
    }else if(textField == self.passwordTF)
    {
        if(self.phoneNumberTF.text.length > 8){
            
        self.subView.contentOffset = CGPointMake(0, self.passwordTF.center.y-230);
            return YES;
            
        }
        else{
            [self alertMessageForTitile:@"Error" forMessage:@"Phone Number Must be 10 Digits"];
            return NO;
        }
    }else if(textField == self.confirmPassword)
    {
        self.subView.contentOffset = CGPointMake(0, self.confirmPassword.center.y-230);
        return YES;
    }
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSLog(@"range of Length: %lu",(unsigned long)range.length);
    if (textField == self.firstNameTF || textField == self.lastName || textField
        == self.middleNameTF)
    {
        NSCharacterSet *blockedCharacters = [NSCharacterSet letterCharacterSet];
        if(range.length == 1)
        {
            return YES;
        }
        else if ([string rangeOfCharacterFromSet:blockedCharacters].location == NSNotFound)
        {
            //[self toastAlertForTitle:@"Error" forMessage:@"Alphabits Only"];
            [self alertMessageForTitile:@"Error" forMessage:@"Enter Alphabits Only"];
            return NO;
            
        }
        else
        {
            return YES;
        }
    }else if (textField == self.phoneNumberTF)
    {
        NSString *stringMobile = [self.phoneNumberTF.text stringByReplacingCharactersInRange:range withString:string];
        
        NSCharacterSet *blockedCharacters = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
        NSLog(@"range of string %@",string);
        NSCharacterSet *forFirstDigit = [NSCharacterSet characterSetWithCharactersInString:@"789"];
        if(range.length == 1)
        {
            return YES;
            //NSLog(@"range of Backspace %@",string);
        }
    else if (self.phoneNumberTF.text.length == 0)
    {
        if([string rangeOfCharacterFromSet:forFirstDigit].location == NSNotFound)
        {
            [self alertMessageForTitile:@"Erroe" forMessage:@"Phone Number Should Start With 7/8/9"];
            return NO;
        }else{
            return YES;
        }
    }
    else if ([string rangeOfCharacterFromSet:blockedCharacters].location != NSNotFound && stringMobile.length <= 10)
    {
        
        return YES;
    }
    else
    {
        //[self toastAlertForTitle:@"Error" forMessage:@"Enter Numbers Only,Length must be 10"];
        [self alertMessageForTitile:@"Error" forMessage:@"Enter Numbers Only,Length must be 10"];
        return NO;
    }
    
    }else
    {
        NSCharacterSet *blockedCharacters = [[NSCharacterSet characterSetWithCharactersInString:@"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz@._1234567890"] invertedSet];
        return ([string rangeOfCharacterFromSet:blockedCharacters].location == NSNotFound);
    }
    
    
    
}

-(void)confirmingDelegaesToTextFields{
    
    self.firstNameTF.delegate = self;
    self.lastName.delegate = self;
    self.middleNameTF.delegate = self;
    self.emailTF.delegate = self;
    self.phoneNumberTF.delegate = self;
    self.passwordTF.delegate = self;
    self.confirmPassword.delegate = self;
    
}
@end
